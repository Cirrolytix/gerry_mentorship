

1.Research objective
2.Datasets to be analyzed
3.Papers to be referenced