# Gerry Acaba Mentorship


Now that you know how github works, please clean up the readme file to include the following:

Objectives for the mentorship.

	1. To put into real action the knowledge acquired from SPARTA training program by elaborating skills and experience into my Portfolio.
	
Current tools you will be using.

	2. Data visualization for further presentation

Subject matter of the project.

	3. census 2024


Summary

I was employed as an LGU staff (Personal Staff of the LCE) in a municipality here in western Samar, Philippinesfrom 2016-2023.
I took the scholarship program of DOST implemented by Development
academy of the Philippines (DAP) called SPARTA and just graduated this September as Analytics Manager with 3micro specialization pathway, namely: 1. Domain knowledge: Urban Planning Pathway, 2. Data Governance. and3. Computing.
Also I earned a certificate on Business Analytics Concept and Framework from The University of the PhilippinesOpen University (UPOU).

When I graduated in SPARTA I thought I will only be dealing with data analysis to be use in decission making within the business world exlcusively. But when I got the certificate of Business Analytics Concepts and Frameworks, all a sudden, I come into a recollection of my past engagement in Community Development, and latest, Local Governance. Now I'm aware of the Impact of AI in this two particular fields- it is a must in order for the Philippines to cope-up with the fast emerging economies of its neighbors, specifically ASEAN.

Data-driven decission-making will ease the burden of Poverty among Filipinos.

x x x x x 
